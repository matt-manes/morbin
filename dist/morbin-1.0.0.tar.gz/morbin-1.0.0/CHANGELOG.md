# Changelog

## v0.1.0 (2023-07-15)

#### New Features

* add ability for Output objects to be added together



## v0.0.0 (2023-07-04)

#### Docs

* write readme
