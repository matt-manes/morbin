from .morbin import Morbin, Output

__version__ = "1.0.0"
