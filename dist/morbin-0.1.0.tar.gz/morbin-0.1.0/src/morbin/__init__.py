from .morbin import Morbin, Output
